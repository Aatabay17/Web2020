export const products = [
  {
    name: 'San Martin',
    price: 226.00,
    description: 'Мужские автоматические механические часы с сапфировым кристаллом, с керамическим ободком, 20 бар.',
    rating: 5.0,
  
  },
  {
    name: 'Crrju',
    price: 149.90,
    description: 'Часовой механизм: кварцевый (сделан в Японии) Материал стекла: Hardlex.',
    rating: 4.8
  },
  {
    name: 'GUANQIN',
    price: 111.52,
    description: 'Материал корпуса: STAINLESS STEEL. Тип материала окошка циферблата: Сапфировый кристалл',
    rating: 0
  },
  {
    name: 'Rolexable',
    price: 119.95,
    description: 'Механизм часов: QUARTZ. Глубина водонепроницаемости: 3 Бар',
    rating: 0
  },
  {
    name: 'Seiko',
    price: 151.05,
    description: 'Механизм часов: Автоматический завод. Длина ремешка: 20cm. Материал корпуса: STAINLESS STEEL',
    rating: 5.0
  },
  {
    name: 'PAGANI',
    price: 208.31,
    description: 'Глубина водонепроницаемости: 10 Бар. Материал корпуса: STAINLESS STEEL. Механизм часов: Механическая ручная заводка. Механизм часов: Автоматический завод',
    rating: 4.8
  },
  {
    name: 'ONOLA',
    price: 37.00,
    description: 'Глубина водонепроницаемости: 3 Бар. Материал корпуса: Сплав. Чехол толщина: 9.5mm',
    rating: 4.9
  },
  {
    name: 'CADISEN',
    price: 299.98,
    description: 'Механизм часов: Автоматический завод. Длина ремешка: 22cm. Стиль: Бизнес',
    rating: 4.9
  },
  {
    name: 'PAGANI',
    price: 131.22,
    description: 'Материал корпуса: STAINLESS STEEL. Чехол толщина: 12mm. Тип материала окошка циферблата: Хардлекс.',
    rating: 5.0
  },
    {
    name: 'NAVIFORCE',
    price: 55.98,
    description: 'Механизм часов: Двойной дисплей. Глубина водонепроницаемости: 3 Бар. Материал корпуса: Сплав',
    rating: 4.9
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/